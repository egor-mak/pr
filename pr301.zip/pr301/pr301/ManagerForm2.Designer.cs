﻿
namespace pr301
{
    partial class ManagerForm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ExitBtn = new System.Windows.Forms.Button();
            this.Report2Btn = new System.Windows.Forms.Button();
            this.Report1Btn = new System.Windows.Forms.Button();
            this.HelloLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ExitBtn
            // 
            this.ExitBtn.Location = new System.Drawing.Point(82, 145);
            this.ExitBtn.Name = "ExitBtn";
            this.ExitBtn.Size = new System.Drawing.Size(148, 37);
            this.ExitBtn.TabIndex = 12;
            this.ExitBtn.Text = "Выйти";
            this.ExitBtn.UseVisualStyleBackColor = true;
            this.ExitBtn.Click += new System.EventHandler(this.ExitBtn_Click);
            // 
            // Report2Btn
            // 
            this.Report2Btn.Location = new System.Drawing.Point(170, 74);
            this.Report2Btn.Name = "Report2Btn";
            this.Report2Btn.Size = new System.Drawing.Size(110, 51);
            this.Report2Btn.TabIndex = 11;
            this.Report2Btn.Text = "Отчет 4";
            this.Report2Btn.UseVisualStyleBackColor = true;
            // 
            // Report1Btn
            // 
            this.Report1Btn.Location = new System.Drawing.Point(26, 74);
            this.Report1Btn.Name = "Report1Btn";
            this.Report1Btn.Size = new System.Drawing.Size(110, 51);
            this.Report1Btn.TabIndex = 10;
            this.Report1Btn.Text = "Отчет 3";
            this.Report1Btn.UseVisualStyleBackColor = true;
            // 
            // HelloLbl
            // 
            this.HelloLbl.AutoSize = true;
            this.HelloLbl.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.HelloLbl.Location = new System.Drawing.Point(22, 26);
            this.HelloLbl.Name = "HelloLbl";
            this.HelloLbl.Size = new System.Drawing.Size(258, 24);
            this.HelloLbl.TabIndex = 9;
            this.HelloLbl.Text = "Добрый день, Костин А.И.";
            // 
            // ManagerForm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(302, 218);
            this.Controls.Add(this.ExitBtn);
            this.Controls.Add(this.Report2Btn);
            this.Controls.Add(this.Report1Btn);
            this.Controls.Add(this.HelloLbl);
            this.Name = "ManagerForm2";
            this.Text = "ManagerForm2";
            this.Load += new System.EventHandler(this.ManagerForm2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ExitBtn;
        private System.Windows.Forms.Button Report2Btn;
        private System.Windows.Forms.Button Report1Btn;
        private System.Windows.Forms.Label HelloLbl;
    }
}