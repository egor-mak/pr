﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using pr301.ModelEF;

namespace pr301
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
        static public Form FORM = null;
        private void MainForm_Load(object sender, EventArgs e)
        {
        }
        private void ExitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void EnterBtn_Click(object sender, EventArgs e)
        {
            if (LoginTxt.Text == "" || PswTxt.Text == "")
            {
                MessageBox.Show("Нужно задать логин и пароль!");
                return;
            }
            Users usr = Program.db.Users.Find(LoginTxt.Text);
            if ((usr != null) && (usr.password == PswTxt.Text))
            {
                Program.USER = usr;
                FORM = this;
                if (usr.roleId == 1)
                {
                    DirectorForm frm = new DirectorForm();
                    frm.Show();
                    this.Hide();
                }
                else if (usr.roleId == 2)
                {
                    ManagerForm frm = new ManagerForm();
                    frm.Show();
                    this.Hide();
                }
                else if (usr.roleId == 3)
                {
                    AdminForm frm = new AdminForm();
                    frm.Show();
                    this.Hide();
                }
            }
            else
            {
                MessageBox.Show("Пользователя с таким логином и паролем нет!");
                return;
            }
        }
    }
}
